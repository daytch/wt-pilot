import React, { useEffect, useState, useMemo } from "react";
import Sidebar from "./../../components/Sidebar";
import { useEffectOnce, isObjectEmpty } from "./../../functions";
import { getData, toogleLoading } from "../../redux/slices/dashboardSlice.js";
import { useDispatch, useSelector } from "react-redux";

const Dashboard = () => {
  
  return (
    <header>
    </header>
  );
};

export default Dashboard;
